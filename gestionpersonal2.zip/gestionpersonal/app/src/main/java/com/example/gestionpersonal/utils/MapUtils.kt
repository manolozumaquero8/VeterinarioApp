package com.example.gestionpersonal.utils

import android.content.Context
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapUtils {
    fun addMarker(map: GoogleMap, location: LatLng, title: String) {
        val marker = MarkerOptions().position(location).title(title)
        map.addMarker(marker)
    }

    fun moveCamera(map: GoogleMap, location: LatLng, zoomLevel: Float) {
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(location, zoomLevel))
    }
}
