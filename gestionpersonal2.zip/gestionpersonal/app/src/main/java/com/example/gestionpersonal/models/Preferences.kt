package com.example.gestionpersonal.models

data class Preferences(
    var notificationsEnabled: Boolean,
    var theme: String
)
