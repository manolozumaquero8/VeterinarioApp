package com.example.gestionpersonal.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gestionpersonal.R
import com.example.gestionpersonal.models.ApiModel

class ApiAdapter(private val data: MutableList<ApiModel>) : RecyclerView.Adapter<ApiAdapter.ApiViewHolder>() {

    // ViewHolder para cada elemento
    class ApiViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.tv_api_title)
        val description: TextView = view.findViewById(R.id.tv_api_description)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ApiViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_api, parent, false)
        return ApiViewHolder(view)
    }

    override fun onBindViewHolder(holder: ApiViewHolder, position: Int) {
        val item = data[position]
        holder.title.text = item.title
        holder.description.text = item.description
    }

    override fun getItemCount(): Int = data.size
}
