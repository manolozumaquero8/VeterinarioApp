package com.example.gestionpersonal.activities

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gestionpersonal.R
import com.example.gestionpersonal.utils.ApiClient
import com.example.gestionpersonal.models.DogResponse
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DogGalleryActivity : AppCompatActivity() {

    private lateinit var dogImageView: ImageView
    private lateinit var fetchDogButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dog_gallery)

        dogImageView = findViewById(R.id.dogImageView)
        fetchDogButton = findViewById(R.id.fetchDogButton)

        fetchDogButton.setOnClickListener {
            fetchRandomDogImage()
        }
    }

    private fun fetchRandomDogImage() {
        ApiClient.dogApiService.getRandomDogImage().enqueue(object : Callback<DogResponse> {
            override fun onResponse(call: Call<DogResponse>, response: Response<DogResponse>) {
                if (response.isSuccessful) {
                    val dogImageUrl = response.body()?.message
                    dogImageUrl?.let {
                        Picasso.get()
                            .load(it)
                            .placeholder(R.drawable.placeholder_image)
                            .error(R.drawable.error_image)
                            .into(dogImageView)
                    }
                } else {
                    Toast.makeText(this@DogGalleryActivity, "Error: ${response.code()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<DogResponse>, t: Throwable) {
                Toast.makeText(this@DogGalleryActivity, "Error al cargar la imagen", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
