package com.example.gestionpersonal.activities

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestionpersonal.R
import com.example.gestionpersonal.adapters.ApiAdapter
import com.example.gestionpersonal.models.ApiModel

class ApiActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_api)

        val recyclerView = findViewById<RecyclerView>(R.id.rv_api_data)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Lista de datos simulada
        val apiData = mutableListOf(
            ApiModel("Título 1", "Descripción 1"),
            ApiModel("Título 2", "Descripción 2"),
            ApiModel("Título 3", "Descripción 3")
        )

        // Configurar adaptador
        val adapter = ApiAdapter(apiData)
        recyclerView.adapter = adapter
    }
}
