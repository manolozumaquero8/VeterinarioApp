package com.example.gestionpersonal.models

data class DogResponse(
    val message: String, // URL de la imagen
    val status: String
)
