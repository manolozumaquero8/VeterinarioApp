package com.example.gestionpersonal.activities

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestionpersonal.R
import com.example.gestionpersonal.adapters.UserAdapter
import com.example.gestionpersonal.database.DatabaseHelper

class ProfileActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var rvUsers: RecyclerView
    private lateinit var userAdapter: UserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Inicializar las vistas
        rvUsers = findViewById(R.id.rv_users)
        val etName = findViewById<EditText>(R.id.et_name)
        val etEmail = findViewById<EditText>(R.id.et_email)
        val btnSave = findViewById<Button>(R.id.btn_save)
        val cbIsChild = findViewById<CheckBox>(R.id.cb_is_child)
        val sbAge = findViewById<SeekBar>(R.id.sb_age)
        val tvAgeLabel = findViewById<TextView>(R.id.tv_age_label)
        val layoutProfile = findViewById<ConstraintLayout>(R.id.layout_profile)

        // Configurar la base de datos y RecyclerView
        dbHelper = DatabaseHelper(this)
        setupRecyclerView()

        // Configurar el SeekBar para mostrar la edad seleccionada
        sbAge.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvAgeLabel.text = "Edad: $progress"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Configurar el botón Guardar
        btnSave.setOnClickListener {
            val name = etName.text.toString()
            val email = etEmail.text.toString()
            val isChild = cbIsChild.isChecked
            val age = sbAge.progress

            if (name.isNotEmpty() && email.isNotEmpty()) {
                val success = dbHelper.insertUser(name, email, isChild, age)
                if (success) {
                    Toast.makeText(this, "Usuario guardado", Toast.LENGTH_SHORT).show()
                    etName.text.clear()
                    etEmail.text.clear()
                    cbIsChild.isChecked = false
                    sbAge.progress = 0

                    // Actualizar el RecyclerView
                    updateRecyclerView()
                    layoutProfile.setBackgroundColor(Color.WHITE)
                } else {
                    Toast.makeText(this, "Error al guardar el usuario", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
            }
        }

        // Cambiar el fondo dinámicamente según el estado del CheckBox
        cbIsChild.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                layoutProfile.setBackgroundColor(Color.parseColor("#FFCDD2")) // Fondo rojo claro
            } else {
                layoutProfile.setBackgroundColor(Color.WHITE) // Fondo blanco
            }
        }
    }

    private fun setupRecyclerView() {
        val users = dbHelper.getAllUsers()
        userAdapter = UserAdapter(users, dbHelper) {
            updateRecyclerView()
        }
        rvUsers.layoutManager = LinearLayoutManager(this)
        rvUsers.adapter = userAdapter
    }

    private fun updateRecyclerView() {
        userAdapter.updateList(dbHelper.getAllUsers())
    }
}
