package com.example.gestionpersonal.models

data class ApiModel(
    val title: String,
    val description: String
)
