package com.example.gestionpersonal.models

data class User(
    val id: Int,
    val name: String,
    val email: String,
    val isChild: Boolean,
    val age: Int
)
