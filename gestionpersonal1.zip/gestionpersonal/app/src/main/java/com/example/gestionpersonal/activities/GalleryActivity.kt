package com.example.gestionpersonal.activities

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.gestionpersonal.R

class GalleryActivity : AppCompatActivity() {

    private val images = listOf(
        R.drawable.image1,
        R.drawable.image2,
        R.drawable.image3
    )

    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        val ivGallery = findViewById<ImageView>(R.id.iv_gallery)
        val btnPrevious = findViewById<Button>(R.id.btn_previous)
        val btnNext = findViewById<Button>(R.id.btn_next)

        // Mostrar la primera imagen
        ivGallery.setImageResource(images[currentIndex])

        // Botón "Anterior"
        btnPrevious.setOnClickListener {
            if (currentIndex > 0) {
                currentIndex--
                ivGallery.setImageResource(images[currentIndex])
            }
        }

        // Botón "Siguiente"
        btnNext.setOnClickListener {
            if (currentIndex < images.size - 1) {
                currentIndex++
                ivGallery.setImageResource(images[currentIndex])
            }
        }
    }
}
