package com.example.gestionpersonal.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.gestionpersonal.models.User

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "UserDatabase.db"
        private const val DATABASE_VERSION = 2 // Incrementa la versión aquí

        private const val TABLE_USERS = "Users"
        private const val COLUMN_ID = "id"
        private const val COLUMN_NAME = "name"
        private const val COLUMN_EMAIL = "email"
        private const val COLUMN_IS_CHILD = "isChild"
        private const val COLUMN_AGE = "age"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = """
            CREATE TABLE $TABLE_USERS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_NAME TEXT,
                $COLUMN_EMAIL TEXT,
                $COLUMN_IS_CHILD INTEGER DEFAULT 0,
                $COLUMN_AGE INTEGER DEFAULT 0
            )
        """
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
    }



    fun getDatabase(): SQLiteDatabase {
        return writableDatabase ?: throw IllegalStateException("Base de datos no disponible")
    }

    fun insertUser(name: String, email: String, isChild: Boolean, age: Int): Boolean {
        return try {
            val db = getDatabase()
            val values = ContentValues().apply {
                put(COLUMN_NAME, name)
                put(COLUMN_EMAIL, email)
                put(COLUMN_IS_CHILD, if (isChild) 1 else 0)
                put(COLUMN_AGE, age)
            }
            db.insertOrThrow(TABLE_USERS, null, values) != -1L
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }


    fun getAllUsers(): List<User> {
        val users = mutableListOf<User>()
        val db = readableDatabase
        val cursor = db.query("Users", null, null, null, null, null, null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
                val email = cursor.getString(cursor.getColumnIndexOrThrow("email"))
                val isChild = cursor.getInt(cursor.getColumnIndexOrThrow("isChild")) == 1
                val age = cursor.getInt(cursor.getColumnIndexOrThrow("age"))
                users.add(User(id, name, email, isChild, age))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return users
    }


    fun deleteUser(userId: Int): Boolean {
        val db = writableDatabase
        return db.delete(TABLE_USERS, "$COLUMN_ID = ?", arrayOf(userId.toString())) > 0
    }
}
