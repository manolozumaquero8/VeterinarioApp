package com.example.gestionpersonal.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.gestionpersonal.R
import com.example.gestionpersonal.databinding.ActivityLoginBinding
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: FirebaseAuth
    private var email = ""
    private var pass = ""

    private val responseLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = data.getResult(ApiException::class.java)
                account?.let {
                    val credential = GoogleAuthProvider.getCredential(it.idToken, null)
                    FirebaseAuth.getInstance().signInWithCredential(credential)
                        .addOnCompleteListener {
                            if (it.isSuccessful) {
                                navigateToDashboard()
                            }
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, it.message.toString(), Toast.LENGTH_SHORT).show()
                        }
                }
            } catch (e: ApiException) {
                Log.d("GoogleSignInError", e.message.toString())
            }
        } else {
            Toast.makeText(this, "El usuario canceló", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth
        setListeners()
    }

    private fun setListeners() {
        binding.btnReset.setOnClickListener { clearFields() }
        binding.btnLogin.setOnClickListener { loginWithEmailPassword() }
        binding.btnRegister.setOnClickListener { registerUser() }
        binding.btnGoogle.setOnClickListener { loginWithGoogle() }
    }

    private fun loginWithGoogle() {
        val googleConfig = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.google_client_id))
            .requestEmail()
            .build()
        val googleClient = GoogleSignIn.getClient(this, googleConfig)

        googleClient.signOut()
        responseLauncher.launch(googleClient.signInIntent)
    }

    private fun loginWithEmailPassword() {
        if (!validateFields()) return
        auth.signInWithEmailAndPassword(email, pass)
            .addOnCompleteListener {
                if (it.isSuccessful) navigateToDashboard()
            }
            .addOnFailureListener { Toast.makeText(this, it.message.toString(), Toast.LENGTH_SHORT).show() }
    }

    private fun registerUser() {
        if (!validateFields()) return
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnCompleteListener { if (it.isSuccessful) loginWithEmailPassword() }
            .addOnFailureListener { Toast.makeText(this, it.message.toString(), Toast.LENGTH_SHORT).show() }
    }

    private fun validateFields(): Boolean {
        email = binding.etEmail.text.toString().trim()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Correo no válido"
            return false
        }
        pass = binding.etPass.text.toString().trim()
        if (pass.length < 6) {
            binding.etPass.error = "La contraseña debe tener al menos 6 caracteres"
            return false
        }
        return true
    }

    private fun clearFields() {
        binding.etPass.setText("")
        binding.etEmail.setText("")
    }

    private fun navigateToDashboard() {
        startActivity(Intent(this, DashboardActivity::class.java))
        finish()
    }

    override fun onStart() {
        super.onStart()
        if (auth.currentUser != null) navigateToDashboard()
    }
}
