package com.example.gestionpersonal.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gestionpersonal.R
import com.example.gestionpersonal.database.DatabaseHelper
import com.example.gestionpersonal.models.User

class UserAdapter(
    private var userList: List<User>,
    private val dbHelper: DatabaseHelper,
    private val onUserListUpdated: () -> Unit
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    class UserViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tv_name)
        val tvEmail: TextView = view.findViewById(R.id.tv_email)
        val tvIsChild: TextView = view.findViewById(R.id.tv_is_child)
        val tvAge: TextView = view.findViewById(R.id.tv_age)
        val btnDelete: Button = view.findViewById(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = userList[position]
        holder.tvName.text = "Nombre: ${user.name}"
        holder.tvEmail.text = "Email: ${user.email}"
        holder.tvIsChild.text = "Niño: ${if (user.isChild) "Sí" else "No"}"
        holder.tvAge.text = "Edad: ${user.age}"

        holder.btnDelete.setOnClickListener {
            if (dbHelper.deleteUser(user.id)) {
                onUserListUpdated()
            }
        }
    }

    override fun getItemCount(): Int = userList.size

    fun updateList(newList: List<User>) {
        userList = newList
        notifyDataSetChanged()
    }
}
