package com.example.gestionpersonal.models

data class DogResponse(
    val message: String,
    val status: String
)
