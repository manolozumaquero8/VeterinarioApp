package com.example.gestionpersonal.activities

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.gestionpersonal.R

class PreferencesActivity : AppCompatActivity() {
    private lateinit var preferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preferences)

        preferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)

        val etPreference = findViewById<EditText>(R.id.et_preference)
        val btnSave = findViewById<Button>(R.id.btn_save_preference)

        btnSave.setOnClickListener {
            val editor = preferences.edit()
            editor.putString("key", etPreference.text.toString())
            editor.apply()
        }
    }
}
