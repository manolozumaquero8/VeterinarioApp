plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.google.gms.google.services)
}

android {
    namespace = "com.example.gestionpersonal"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.gestionpersonal"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    viewBinding{
        enable = true
    }
}

dependencies {
    // Core Android libraries
    implementation (libs.retrofit.v2110)
    implementation (libs.converter.gson.v2110)

    implementation(libs.play.services.auth.v2120) // Última versión
    implementation(libs.play.services.identity) // Nueva API para Identity
    implementation (libs.androidx.constraintlayout.v214)
    implementation(libs.firebase.auth.ktx)
    implementation(libs.play.services.auth.v2120)
    implementation(libs.google.services.v440)

    implementation (libs.google.services)
    implementation(libs.picasso)
    implementation (libs.play.services.maps.v1802)
    implementation (libs.play.services.maps.v1900)
    implementation (libs.play.services.location)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation (libs.play.services.auth.v2120)

    // Firebase Authentication
    implementation(libs.firebase.auth.v2310)
    implementation(libs.play.services.auth.v2120)

    // Google Maps
    implementation(libs.play.services.maps.v1900)

    // Retrofit (for API consumption)
    implementation(libs.retrofit.v2110)
    implementation(libs.converter.gson.v2110)

    // RecyclerView (for gallery and API data display)
    implementation(libs.androidx.recyclerview.v132)

    // Unit testing
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    implementation(kotlin("script-runtime"))
}
